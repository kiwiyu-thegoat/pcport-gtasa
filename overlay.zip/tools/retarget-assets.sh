#!/usr/bin/env bash
# Rewrites the data path that is baked into Winlator's bundled Linux system files
# (glibc, Wine, X11, Box64 ... all contain /data/data/com.winlator/files/rootfs).
#
# The new app ID is longer than "com.winlator", so a normal rewrite would corrupt the binaries.
# Instead the old 36-character prefix is replaced by a 36-character one that ends in slashes:
#     /data/data/com.pcport.gtasa/r///////        (extra slashes are ignored by Linux)
# and the app creates a symlink  <data dir>/r -> <data dir>/files/rootfs  at startup
# (see SALauncher.ensureRootfsAlias). Same length = every ELF file, ld.so.cache and
# string table stays valid.
#
#   ./retarget-assets.sh /path/to/winlator-app/app/src/main/assets
#
# Needs: zstd, tar, perl, grep.  Set KEEP_BACKUP=1 to keep *.bak copies (off by default).
set -u

OLD="/data/data/com.winlator/files/rootfs"
NEWBASE="${NEWBASE:-/data/data/com.pcport.gtasa/r}"
ASSETS="${1:?usage: $0 <assets-dir>}"

pad=$(( ${#OLD} - ${#NEWBASE} ))
if (( pad < 0 )); then echo "NEWBASE is longer than the old path, cannot patch in place"; exit 1; fi
NEW="$NEWBASE"
for ((i = 0; i < pad; i++)); do NEW+="/"; done
if (( ${#NEW} != ${#OLD} )); then echo "length mismatch"; exit 1; fi
echo "Replacing: $OLD"
echo "     with: $NEW"

for tool in zstd tar perl grep; do
  command -v "$tool" >/dev/null || { echo "missing tool: $tool"; exit 1; }
done
export OLD NEW

# Removes assets the GTA SA launcher can never use (see SARenderer / SALauncher.WINCOMPONENTS).
slim_assets() {
  echo "== removing unused assets"
  local before after
  before="$(du -sm "$ASSETS" | cut -f1)"
  rm -f  "$ASSETS"/dxwrapper/dxvk-2.4.1.tzst "$ASSETS"/dxwrapper/d7vk-*.tzst
  rm -rf "$ASSETS"/dxwrapper/cnc-ddraw-*
  rm -f  "$ASSETS"/graphics_driver/zink-*.tzst "$ASSETS"/graphics_driver/virgl-*.tzst
  for c in direct3d xaudio wmdecoder vcrun2005 vcrun2010 directshow directplay; do
    rm -f "$ASSETS/wincomponents/$c.tzst"
  done
  after="$(du -sm "$ASSETS" | cut -f1)"
  echo "assets: ${before} MB -> ${after} MB"
}

# Trims files that are never needed at runtime and prints what is big inside rootfs.
trim_rootfs() {
  local work="$1" before after
  before="$(du -sm "$work" | cut -f1)"
  rm -rf "$work"/usr/share/doc "$work"/usr/share/man "$work"/usr/share/info "$work"/usr/share/gtk-doc "$work"/usr/include
  find "$work" \( -name '*.a' -o -name '*.la' -o -name '*.pyc' \) -type f -delete 2>/dev/null
  after="$(du -sm "$work" | cut -f1)"
  echo "rootfs trimmed: ${before} MB -> ${after} MB (uncompressed)"
  echo "largest folders in rootfs (MB):"
  du -m --max-depth=3 "$work" 2>/dev/null | sort -rn | sed -n 2,26p
}

fix_archive() {
  local archive="$1" work count left
  work="$(mktemp -d)"
  echo "== $archive"

  if ! zstd -dcq "$archive" | tar -xp -C "$work"; then
    echo "!! could not extract, archive left unchanged"
    rm -rf "$work"
    return
  fi
  chmod -R u+rwX "$work" 2>/dev/null

  [[ "$archive" == */rootfs.tzst ]] && trim_rootfs "$work"

  # 1) absolute symlinks that point into the old path
  find "$work" -type l | while read -r link; do
    target="$(readlink "$link")"
    if [[ "$target" == "$OLD"* ]]; then
      ln -sfn "${NEW}${target#"$OLD"}" "$link"
    fi
  done

  # 2) every regular file (binary or text) that contains the old path: same-length byte replace
  count=0
  while read -r f; do
    [[ -L "$f" ]] && continue
    perl -0777 -pi -e 's/\Q$ENV{OLD}\E/$ENV{NEW}/g' "$f" && count=$((count + 1))
  done < <(grep -rlaF "$OLD" "$work" 2>/dev/null)
  echo "patched $count file(s)"

  # 3) anything still mentioning the old package, in any other form
  left="$(grep -rhaoE '/data/data/com\.winlator[A-Za-z0-9_./-]*' "$work" 2>/dev/null | sort | uniq -c | sort -rn | head -20)"
  if [[ -n "$left" ]]; then
    echo "STILL CONTAINS other forms of the old path (these may need handling):"
    echo "$left"
  fi

  # 4) show the loader path box64 will use
  find "$work" -name box64 -type f | while read -r b; do
    echo "box64 loader path: $(grep -aoE '/data/data/[A-Za-z0-9_.]+/[A-Za-z0-9_/.-]*ld-linux-aarch64\.so\.1' "$b" | head -1)"
  done

  [[ "${KEEP_BACKUP:-0}" == "1" ]] && cp -n "$archive" "$archive.bak"
  if tar -C "$work" --owner=0 --group=0 --numeric-owner -c . | zstd -19 -T0 -q -f -o "$archive.new"; then
    mv "$archive.new" "$archive"
  else
    echo "!! repack failed, archive left unchanged"
    rm -f "$archive.new"
  fi
  rm -rf "$work"
}

slim_assets

for archive in \
  "$ASSETS"/rootfs.tzst \
  "$ASSETS"/rootfs_patches.tzst \
  "$ASSETS"/container_pattern.tzst \
  "$ASSETS"/pulseaudio.tzst \
  "$ASSETS"/box64/*.tzst \
  "$ASSETS"/graphics_driver/*.tzst; do
  [[ -f "$archive" ]] && fix_archive "$archive"
done
echo "Done."
