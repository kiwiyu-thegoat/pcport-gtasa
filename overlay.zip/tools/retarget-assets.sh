#!/usr/bin/env bash
# Rewrites the old Winlator data path inside the bundled asset archives so they work
# under the new app ID. Run on a PC/Linux (or Termux) BEFORE building the APK.
#
#   ./retarget-assets.sh /path/to/winlator-app/app/src/main/assets
#
# Needs: zstd, tar, patchelf, file.   Originals are kept as *.bak.
# NOT TESTED by the author. Read the "STILL CONTAINS" report at the end.
set -euo pipefail

OLD="/data/data/com.winlator"
NEW="/data/data/com.pcport.gtasa"
ASSETS="${1:?usage: $0 <assets-dir>}"

for tool in zstd tar patchelf file; do
  command -v "$tool" >/dev/null || { echo "missing tool: $tool"; exit 1; }
done

fix_archive() {
  local archive="$1" work
  work="$(mktemp -d)"
  echo "== $archive"
  zstd -dcq "$archive" | tar -xp -C "$work"

  # 1) absolute symlinks pointing into the old data dir
  find "$work" -type l | while read -r link; do
    target="$(readlink "$link")"
    if [[ "$target" == "$OLD"* ]]; then
      ln -sfn "${NEW}${target#"$OLD"}" "$link"
    fi
  done

  # 2) ELF files: interpreter and rpath/runpath
  find "$work" -type f | while read -r f; do
    file -b "$f" | grep -q '^ELF' || continue
    interp="$(patchelf --print-interpreter "$f" 2>/dev/null || true)"
    if [[ "$interp" == "$OLD"* ]]; then
      patchelf --set-interpreter "${NEW}${interp#"$OLD"}" "$f"
    fi
    rpath="$(patchelf --print-rpath "$f" 2>/dev/null || true)"
    if [[ "$rpath" == *"$OLD"* ]]; then
      patchelf --set-rpath "${rpath//$OLD/$NEW}" "$f"
    fi
  done

  # 3) plain-text files (scripts, configs, registry files)
  grep -rIlF "$OLD" "$work" 2>/dev/null | while read -r f; do
    sed -i "s#${OLD}#${NEW}#g" "$f"
  done

  # 4) report anything we could not fix (path baked into a binary)
  local left
  left="$(grep -rlaF "$OLD" "$work" 2>/dev/null || true)"
  if [[ -n "$left" ]]; then
    echo "STILL CONTAINS the old path (cannot patch safely):"
    echo "$left" | sed "s#^$work/#   #"
  fi

  [[ "${KEEP_BACKUP:-1}" == "1" ]] && cp -n "$archive" "$archive.bak"
  tar -C "$work" -c . | zstd -19 -q -f -o "$archive"
  rm -rf "$work"
}

for archive in \
  "$ASSETS"/rootfs.tzst \
  "$ASSETS"/rootfs_patches.tzst \
  "$ASSETS"/container_pattern.tzst \
  "$ASSETS"/pulseaudio.tzst \
  "$ASSETS"/box64/*.tzst \
  "$ASSETS"/graphics_driver/*.tzst; do
  [[ -f "$archive" ]] && fix_archive "$archive"
done
echo "Done. Review any 'STILL CONTAINS' lines above."
