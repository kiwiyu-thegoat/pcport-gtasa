package com.winlator.sa;

import android.content.Context;

import com.winlator.core.AppUtils;
import com.winlator.core.Callback;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.RandomAccessFile;
import java.io.StringWriter;

/** Always-on log: everything Box64/Wine print plus our own diagnostics, saved to a file the user can read. */
public abstract class SALog {
    private static final long MAX_BYTES = 6L * 1024 * 1024;
    private static BufferedWriter writer;
    private static long written;
    private static Callback<String> errorListener;

    /** Download/GTA_SA_Launcher/log.txt, or the app's private folder if Download is not writable. */
    public static File logFile(Context context) {
        File dir = new File(AppUtils.DIRECTORY_DOWNLOADS, "GTA_SA_Launcher");
        if (!dir.isDirectory()) dir.mkdirs();
        if (!dir.isDirectory() || !dir.canWrite()) dir = context.getFilesDir();
        return new File(dir, "log.txt");
    }

    public static synchronized void start(Context context) {
        close();
        try {
            writer = new BufferedWriter(new FileWriter(logFile(context), false));
            written = 0;
        }
        catch (Exception e) {
            writer = null;
        }
        write("=== GTA SA Launcher log " + new java.util.Date() + " ===");
    }

    public static synchronized void close() {
        try {
            if (writer != null) writer.close();
        }
        catch (Exception e) {}
        writer = null;
    }

    public static synchronized void write(String line) {
        if (writer == null || written > MAX_BYTES) return;
        try {
            writer.write(line);
            writer.newLine();
            writer.flush();
            written += line.length() + 1;
        }
        catch (Exception e) {}
    }

    public static void error(String message, Throwable error) {
        StringWriter stack = new StringWriter();
        if (error != null) error.printStackTrace(new PrintWriter(stack));
        write("ERROR: " + message + "\n" + stack);
    }

    public static void setErrorListener(Callback<String> listener) {
        errorListener = listener;
    }

    /** Logs the problem and tells the running game screen to show it instead of hanging silently. */
    public static void fatal(String message) {
        write("FATAL: " + message);
        Callback<String> listener = errorListener;
        if (listener != null) listener.call(message);
    }

    /** Last maxChars characters of the saved log (empty string if there is none). */
    public static String readTail(Context context, int maxChars) {
        File file = logFile(context);
        if (!file.isFile()) return "";
        try (RandomAccessFile reader = new RandomAccessFile(file, "r")) {
            long start = Math.max(0, reader.length() - maxChars);
            reader.seek(start);
            byte[] data = new byte[(int)(reader.length() - start)];
            reader.readFully(data);
            return new String(data, "UTF-8");
        }
        catch (Exception e) {
            return "";
        }
    }
}
