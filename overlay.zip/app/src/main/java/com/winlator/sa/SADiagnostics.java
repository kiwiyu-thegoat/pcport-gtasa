package com.winlator.sa;

import android.os.Build;

import java.io.File;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/** Writes the facts we need to understand a failed start (paths, permissions, ELF interpreter). */
public abstract class SADiagnostics {
    public static void logLaunch(File rootDir, String command) {
        SALog.write("Device: " + Build.MANUFACTURER + " " + Build.MODEL + ", Android " + Build.VERSION.RELEASE + ", ABI " + Build.SUPPORTED_ABIS[0]);
        SALog.write("Root dir: " + rootDir + " (exists=" + rootDir.isDirectory() + ")");
        SALog.write("Command: " + command);

        File alias = new File(rootDir.getParentFile().getParentFile(), "r");
        SALog.write("rootfs alias " + alias + ": exists=" + alias.exists() + ", box64 reachable through it=" + new File(alias, "usr/local/bin/box64").isFile());

        File box64 = new File(rootDir, "usr/local/bin/box64");
        SALog.write("box64: exists=" + box64.isFile() + ", size=" + box64.length() + ", executable=" + box64.canExecute());

        String interpreter = readInterpreter(box64);
        SALog.write("box64 ELF interpreter: " + interpreter);
        if (interpreter != null && interpreter.startsWith("/")) {
            SALog.write("interpreter exists on this device: " + new File(interpreter).exists());
        }

        File wine = new File(rootDir, "opt/wine/bin/wine");
        SALog.write("wine: exists=" + wine.exists() + ", executable=" + wine.canExecute());
        File lib = new File(rootDir, "lib");
        String[] libs = lib.list();
        SALog.write("rootfs lib entries: " + (libs != null ? libs.length : -1));
    }

    /** Reads PT_INTERP from an ELF file, or a short note if there is none. */
    public static String readInterpreter(File file) {
        if (!file.isFile()) return "(file missing)";
        try (RandomAccessFile reader = new RandomAccessFile(file, "r")) {
            byte[] header = new byte[64];
            reader.readFully(header);
            if (header[0] != 0x7f || header[1] != 'E' || header[2] != 'L' || header[3] != 'F') return "(not an ELF file)";

            boolean is64 = header[4] == 2;
            ByteOrder order = header[5] == 1 ? ByteOrder.LITTLE_ENDIAN : ByteOrder.BIG_ENDIAN;
            ByteBuffer eh = ByteBuffer.wrap(header).order(order);

            long phoff = is64 ? eh.getLong(32) : (eh.getInt(28) & 0xffffffffL);
            int phentsize = eh.getShort(is64 ? 54 : 42) & 0xffff;
            int phnum = eh.getShort(is64 ? 56 : 44) & 0xffff;

            for (int i = 0; i < phnum; i++) {
                byte[] entry = new byte[phentsize];
                reader.seek(phoff + (long)i * phentsize);
                reader.readFully(entry);
                ByteBuffer ph = ByteBuffer.wrap(entry).order(order);
                if (ph.getInt(0) != 3) continue; // PT_INTERP

                long offset = is64 ? ph.getLong(8) : (ph.getInt(4) & 0xffffffffL);
                long size = is64 ? ph.getLong(32) : (ph.getInt(16) & 0xffffffffL);
                byte[] text = new byte[(int)Math.min(size, 512)];
                reader.seek(offset);
                reader.readFully(text);
                String value = new String(text, "UTF-8");
                int end = value.indexOf('\0');
                return end >= 0 ? value.substring(0, end) : value;
            }
            return "(none, static or uses the system linker)";
        }
        catch (Exception e) {
            return "(could not read: " + e + ")";
        }
    }
}
