package com.winlator.sa;

import android.content.Context;

import com.winlator.container.Container;
import com.winlator.container.ContainerManager;
import com.winlator.container.DXWrappers;
import com.winlator.container.GraphicsDrivers;
import com.winlator.core.Callback;
import com.winlator.xenvironment.RootFS;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;

/** Container setup and game lookup for the GTA SA-only launcher. */
public abstract class SALauncher {
    public static final String CONTAINER_NAME = "GTA SA";
    /** gta_sa.exe (case-insensitive) directly inside dir, or inside one of its immediate subfolders. */
    public static File findExeIn(File dir) {
        if (dir == null || !dir.isDirectory()) return null;
        File[] files = dir.listFiles();
        if (files == null) return null;

        for (File file : files) {
            if (file.isFile() && file.getName().equalsIgnoreCase("gta_sa.exe")) return file;
        }
        for (File file : files) {
            if (!file.isDirectory()) continue;
            File[] children = file.listFiles();
            if (children == null) continue;
            for (File child : children) {
                if (child.isFile() && child.getName().equalsIgnoreCase("gta_sa.exe")) return child;
            }
        }
        return null;
    }

    /**
     * Converts a folder URI from the system picker (ACTION_OPEN_DOCUMENT_TREE) into a real path.
     * Works for internal storage and SD cards; returns null for providers without a file path
     * (for example the Downloads root on newer Android).
     */
    public static File treeUriToFile(android.net.Uri uri) {
        try {
            String docId = android.provider.DocumentsContract.getTreeDocumentId(uri);
            int index = docId.indexOf(':');
            if (index == -1) return null;

            String volume = docId.substring(0, index);
            String relative = docId.substring(index + 1);
            File base = volume.equalsIgnoreCase("primary") ? android.os.Environment.getExternalStorageDirectory() : new File("/storage/" + volume);
            return relative.isEmpty() ? base : new File(base, relative);
        }
        catch (Exception e) {
            return null;
        }
    }

    /** Default drives plus G: pointing at the game folder, wherever it lives. */
    public static String drivesFor(File exe) {
        return Container.DEFAULT_DRIVES + "G:" + exe.getParentFile().getPath();
    }

    /**
     * The bundled system files look for themselves under <data dir>/r (see tools/retarget-assets.sh).
     * This creates that symlink, pointing at the real rootfs folder. Safe to call repeatedly.
     */
    public static void ensureRootfsAlias(Context context) {
        try {
            File rootDir = RootFS.find(context).getRootDir();
            File alias = new File(context.getFilesDir().getParentFile(), "r");
            String target = rootDir.getPath();
            try {
                if (target.equals(android.system.Os.readlink(alias.getPath()))) return;
            }
            catch (Exception e) {}
            alias.delete();
            android.system.Os.symlink(target, alias.getPath());
        }
        catch (Exception e) {
            SALog.error("Could not create the rootfs alias link", e);
        }
    }

    public static Container findContainer(ContainerManager manager) {
        for (Container container : manager.getContainers()) {
            if (CONTAINER_NAME.equals(container.getName())) return container;
        }
        return null;
    }

    public static void createContainer(ContainerManager manager, SAProfile profile, File exe, Callback<Container> callback) {
        try {
            JSONObject data = new JSONObject();
            data.put("name", CONTAINER_NAME);
            data.put("screenSize", profile.screenSize);
            data.put("graphicsDriver", GraphicsDrivers.TURNIP + "," + GraphicsDrivers.DEFAULT_OPENGL_DRIVER);
            data.put("dxwrapper", DXWrappers.DXVK);
            data.put("dxwrapperConfig", profile.dxwrapperConfig());
            data.put("box64Preset", profile.box64Preset);
            data.put("cpuList", detectBigCores());
            data.put("cpuListWoW64", detectBigCores());
            data.put("drives", drivesFor(exe));
            data.put("showFPS", true); // handy while tuning; remove later
            data.put("envVars", Container.DEFAULT_ENV_VARS + " WINEDLLOVERRIDES=dinput8=n,b;vorbisFile=n,b");
            manager.createContainerAsync(data, callback);
        }
        catch (JSONException e) {
            callback.call(null);
        }
    }

    /** Re-applies the selected profile to an existing container. */
    public static void applyProfile(Container container, SAProfile profile, File exe) {
        container.setDrives(drivesFor(exe));
        container.setScreenSize(profile.screenSize);
        container.setDXWrapper(DXWrappers.DXVK);
        container.setDXWrapperConfig(profile.dxwrapperConfig());
        container.setBox64Preset(profile.box64Preset);
        container.setCPUList(detectBigCores());
        container.setCPUListWoW64(detectBigCores());
        container.saveData();
    }

    /**
     * Picks the fast cores by max frequency (Snapdragon 680: 4x A73 + 4x A53).
     * Falls back to "all cores" (empty string = Winlator default) if sysfs is unreadable.
     */
    public static String detectBigCores() {
        int count = Runtime.getRuntime().availableProcessors();
        long[] freq = new long[count];
        long max = 0;
        for (int i = 0; i < count; i++) {
            freq[i] = readLong("/sys/devices/system/cpu/cpu" + i + "/cpufreq/cpuinfo_max_freq");
            max = Math.max(max, freq[i]);
        }
        if (max <= 0) return "";

        ArrayList<String> big = new ArrayList<>();
        for (int i = 0; i < count; i++) if (freq[i] >= max * 0.85) big.add(String.valueOf(i));
        return big.size() > 0 && big.size() < count ? String.join(",", big) : "";
    }

    private static long readLong(String path) {
        try (java.io.BufferedReader reader = new java.io.BufferedReader(new java.io.FileReader(path))) {
            return Long.parseLong(reader.readLine().trim());
        }
        catch (Exception e) {
            return 0;
        }
    }
}
