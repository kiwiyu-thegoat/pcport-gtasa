package com.winlator.sa;

import com.winlator.box64.Box64Preset;

/**
 * Performance profiles tuned for low/mid-range Adreno (Snapdragon 680 / Adreno 610 baseline).
 * DXVK 1.10.3 is pinned on purpose: it needs far less from the Vulkan driver than DXVK 2.x.
 */
public enum SAProfile {
    LOW("Low (smoothest)", "854x480", 30),
    BALANCED("Balanced", "1280x720", 30),
    HIGH("High", "1280x720", 45);

    public static final String DXVK_VERSION = "1.10.3";

    public final String label;
    public final String screenSize;
    public final int fps;
    public final String box64Preset = Box64Preset.PERFORMANCE;

    SAProfile(String label, String screenSize, int fps) {
        this.label = label;
        this.screenSize = screenSize;
        this.fps = fps;
    }

    /** KeyValueSet string understood by DXVKConfigDialog / XServerDisplayActivity. */
    public String dxwrapperConfig() {
        return "version=" + DXVK_VERSION + ",framerate=" + fps;
    }

    public static SAProfile fromName(String name, SAProfile fallback) {
        try {
            return valueOf(name);
        }
        catch (Exception e) {
            return fallback;
        }
    }
}
