package com.winlator.sa;

import com.winlator.container.DXWrappers;
import com.winlator.container.GraphicsDrivers;

/** Graphics paths to try. If one gives a black screen, switch to the next and press Play again. */
public enum SARenderer {
    TURNIP_DXVK("1. Turnip + DXVK (default)", GraphicsDrivers.TURNIP, "", DXWrappers.DXVK),
    TURNIP_SAFE("2. Turnip, safe display mode", GraphicsDrivers.TURNIP, "directRendering=0", DXWrappers.DXVK),
    VORTEK_DXVK("3. Phone's own Vulkan driver (Vortek)", GraphicsDrivers.VORTEK, "", DXWrappers.DXVK),
    WINED3D("4. OpenGL (WineD3D, slowest)", GraphicsDrivers.TURNIP, "", DXWrappers.WINED3D);

    public static final String DXVK_VERSION = "1.10.3";

    public final String label;
    public final String vulkanDriver;
    public final String graphicsDriverConfig;
    public final String dxwrapper;

    SARenderer(String label, String vulkanDriver, String graphicsDriverConfig, String dxwrapper) {
        this.label = label;
        this.vulkanDriver = vulkanDriver;
        this.graphicsDriverConfig = graphicsDriverConfig;
        this.dxwrapper = dxwrapper;
    }

    public String graphicsDriver() {
        return vulkanDriver + "," + GraphicsDrivers.DEFAULT_OPENGL_DRIVER;
    }

    public String dxwrapperConfig(int fps) {
        return dxwrapper.equals(DXWrappers.DXVK) ? "version=" + DXVK_VERSION + ",framerate=" + fps : "";
    }

    public static SARenderer fromName(String name, SARenderer fallback) {
        try {
            return valueOf(name);
        }
        catch (Exception e) {
            return fallback;
        }
    }
}
