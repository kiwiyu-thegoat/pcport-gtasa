package com.winlator;

import android.Manifest;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.preference.PreferenceManager;

import com.winlator.container.Container;
import com.winlator.container.ContainerManager;
import com.winlator.core.AppUtils;
import com.winlator.core.UnitUtils;
import com.winlator.sa.SALauncher;
import com.winlator.sa.SALog;
import com.winlator.sa.SAProfile;
import com.winlator.sa.SARenderer;
import com.winlator.xenvironment.RootFS;
import com.winlator.xenvironment.RootFSInstaller;

import java.io.File;

/** Single-purpose home screen: choose the game folder, pick a profile, press Play. */
public class SALauncherActivity extends AppCompatActivity {
    private static final int REQUEST_STORAGE = 101;
    private static final int REQUEST_PICK_FOLDER = 102;
    private static final String PREF_PROFILE = "sa_profile";
    private static final String PREF_RENDERER = "sa_renderer";
    private static final String PREF_SKIP_INTRO = "sa_skip_intro";
    private static final String PREF_GAME_EXE = "sa_game_exe";

    private SharedPreferences preferences;
    private TextView statusView;
    private Button playButton;
    private RadioGroup profileGroup;
    private RadioGroup rendererGroup;
    private CheckBox skipIntroBox;
    private File gameExe;
    private boolean installing = false;
    private boolean autoInstallTried = false;
    private boolean permissionAsked = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        AppUtils.setActivityTheme(this);
        super.onCreate(savedInstanceState);
        preferences = PreferenceManager.getDefaultSharedPreferences(this);
        SALauncher.ensureRootfsAlias(this);

        String saved = preferences.getString(PREF_GAME_EXE, null);
        if (saved != null && new File(saved).isFile()) gameExe = new File(saved);

        setContentView(buildUi());
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (gameExe != null && !gameExe.isFile()) gameExe = null; // folder moved or deleted

        if (!hasStoragePermission() && !permissionAsked) {
            permissionAsked = true;
            requestStoragePermission();
        }
        // First start: install the bundled system files automatically.
        if (!autoInstallTried && !isSystemReady()) {
            autoInstallTried = true;
            installSystemFiles();
        }
        refreshStatus();
    }

    private View buildUi() {
        int pad = (int)UnitUtils.dpToPx(24);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("GTA San Andreas");
        title.setTextSize(26);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        statusView = new TextView(this);
        statusView.setTextSize(14);
        statusView.setPadding(0, pad, 0, pad);
        root.addView(statusView);

        Button folderButton = new Button(this);
        folderButton.setText("Select game folder");
        folderButton.setOnClickListener(v -> pickFolder());
        root.addView(folderButton);

        TextView rendererTitle = new TextView(this);
        rendererTitle.setText("Graphics (try the next one if the screen stays black):");
        rendererTitle.setPadding(0, pad / 2, 0, 0);
        root.addView(rendererTitle);

        rendererGroup = new RadioGroup(this);
        SARenderer savedRenderer = SARenderer.fromName(preferences.getString(PREF_RENDERER, null), SARenderer.TURNIP_DXVK);
        for (SARenderer renderer : SARenderer.values()) {
            RadioButton button = new RadioButton(this);
            button.setId(View.generateViewId());
            button.setTag(renderer);
            button.setText(renderer.label);
            rendererGroup.addView(button);
            if (renderer == savedRenderer) button.setChecked(true);
        }
        root.addView(rendererGroup);

        TextView profileTitle = new TextView(this);
        profileTitle.setText("Performance:");
        profileTitle.setPadding(0, pad / 2, 0, 0);
        root.addView(profileTitle);

        profileGroup = new RadioGroup(this);
        SAProfile savedProfile = SAProfile.fromName(preferences.getString(PREF_PROFILE, null), SAProfile.BALANCED);
        for (SAProfile profile : SAProfile.values()) {
            RadioButton button = new RadioButton(this);
            button.setId(View.generateViewId());
            button.setTag(profile);
            button.setText(profile.label + "  (" + profile.screenSize + ", " + profile.fps + " fps)");
            profileGroup.addView(button);
            if (profile == savedProfile) button.setChecked(true);
        }
        root.addView(profileGroup);

        skipIntroBox = new CheckBox(this);
        skipIntroBox.setText("Skip intro videos (fixes the black screen)");
        skipIntroBox.setChecked(preferences.getBoolean(PREF_SKIP_INTRO, true));
        root.addView(skipIntroBox);

        playButton = new Button(this);
        playButton.setText("Play");
        playButton.setOnClickListener(v -> onPlay());
        root.addView(playButton);

        Button logButton = new Button(this);
        logButton.setText("Copy last log");
        logButton.setOnClickListener(v -> copyLog());
        root.addView(logButton);

        return root;
    }

    private boolean hasStoragePermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED &&
               ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestStoragePermission() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE}, REQUEST_STORAGE);
    }

    private boolean isSystemReady() {
        RootFS rootFS = RootFS.find(this);
        return rootFS.isValid() && rootFS.getVersion() >= RootFSInstaller.LATEST_VERSION;
    }

    private SAProfile selectedProfile() {
        View checked = profileGroup.findViewById(profileGroup.getCheckedRadioButtonId());
        return checked != null && checked.getTag() instanceof SAProfile ? (SAProfile)checked.getTag() : SAProfile.BALANCED;
    }

    private SARenderer selectedRenderer() {
        View checked = rendererGroup.findViewById(rendererGroup.getCheckedRadioButtonId());
        return checked != null && checked.getTag() instanceof SARenderer ? (SARenderer)checked.getTag() : SARenderer.TURNIP_DXVK;
    }

    private void refreshStatus() {
        boolean permission = hasStoragePermission();
        boolean system = isSystemReady();

        StringBuilder sb = new StringBuilder();
        sb.append(permission ? "[OK] Storage permission\n" : "[ ] Storage permission (tap Play to grant)\n");
        sb.append(system ? "[OK] System files installed\n" : (installing ? "[..] Installing system files, please wait\n" : "[ ] System files not installed (tap Play to retry)\n"));
        sb.append(gameExe != null ? "[OK] Game folder: " + gameExe.getParent() + "\n" : "[ ] Game folder not selected (tap Select game folder)\n");
        statusView.setText(sb.toString());
    }

    private void pickFolder() {
        if (!hasStoragePermission()) {
            requestStoragePermission();
            return;
        }
        startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), REQUEST_PICK_FOLDER);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_PICK_FOLDER || resultCode != RESULT_OK || data == null || data.getData() == null) return;

        File dir = SALauncher.treeUriToFile(data.getData());
        if (dir == null) {
            Toast.makeText(this, "Can't read that location. Pick the folder from Internal storage or your SD card (not the Downloads shortcut).", Toast.LENGTH_LONG).show();
            return;
        }

        File exe = SALauncher.findExeIn(dir);
        if (exe == null) {
            Toast.makeText(this, "gta_sa.exe not found in that folder. Pick the folder that contains gta_sa.exe.", Toast.LENGTH_LONG).show();
            return;
        }

        gameExe = exe;
        preferences.edit().putString(PREF_GAME_EXE, exe.getPath()).apply();
        refreshStatus();
    }

    private void installSystemFiles() {
        if (installing) return;
        installing = true;
        playButton.setEnabled(false);
        RootFSInstaller.install(this, () -> {
            installing = false;
            playButton.setEnabled(true);
            SALauncher.ensureRootfsAlias(this);
            refreshStatus();
            Toast.makeText(this, isSystemReady() ? "System files installed." : "Installation failed. Tap Play to retry.", Toast.LENGTH_LONG).show();
        });
    }

    private void copyLog() {
        String text = SALog.readTail(this, 30000) + SALauncher.readDxvkLogs(this, 6000);
        if (text.isEmpty()) {
            Toast.makeText(this, "No log yet. Press Play first.", Toast.LENGTH_LONG).show();
            return;
        }
        ClipboardManager clipboard = (ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
        clipboard.setPrimaryClip(ClipData.newPlainText("GTA SA log", text));
        Toast.makeText(this, "Log copied. Also saved at " + SALog.logFile(this).getPath(), Toast.LENGTH_LONG).show();
    }

    private void onPlay() {
        if (!hasStoragePermission()) {
            requestStoragePermission();
            return;
        }

        if (!isSystemReady()) {
            installSystemFiles(); // normally done automatically at first start; this is the retry path
            return;
        }

        final File exe = gameExe;
        if (exe == null || !exe.isFile()) {
            Toast.makeText(this, "Select your GTA SA game folder first.", Toast.LENGTH_LONG).show();
            return;
        }

        final SAProfile profile = selectedProfile();
        final SARenderer renderer = selectedRenderer();
        final boolean skipIntro = skipIntroBox.isChecked();
        preferences.edit().putString(PREF_PROFILE, profile.name()).putString(PREF_RENDERER, renderer.name()).putBoolean(PREF_SKIP_INTRO, skipIntro).apply();
        SALauncher.setIntroSkipped(exe.getParentFile(), skipIntro);
        playButton.setEnabled(false);

        final ContainerManager manager = new ContainerManager(this);
        Container container = SALauncher.findContainer(manager);
        if (container != null) {
            launch(container, profile, renderer, exe);
        }
        else {
            statusView.setText("Creating GTA SA container (first run only)...");
            SALauncher.createContainer(manager, profile, renderer, exe, created -> {
                if (created == null) {
                    playButton.setEnabled(true);
                    Toast.makeText(this, "Could not create the container.", Toast.LENGTH_LONG).show();
                    refreshStatus();
                }
                else launch(created, profile, renderer, exe);
            });
        }
    }

    private void launch(Container container, SAProfile profile, SARenderer renderer, File exe) {
        SALauncher.ensureRootfsAlias(this);
        SALauncher.applyProfile(container, profile, renderer, exe);
        String info = "Selected: profile=" + profile + ", renderer=" + renderer + ", skipIntro=" + skipIntroBox.isChecked() + "\n" +
                      "Container: screen=" + container.getScreenSize() + ", graphicsDriver=" + container.getGraphicsDriver() +
                      ", graphicsDriverConfig=" + container.getGraphicsDriverConfig() + ", dxwrapper=" + container.getDXWrapper() +
                      " (" + container.getDXWrapperConfig() + ")\nGame: " + exe;

        Intent intent = new Intent(this, XServerDisplayActivity.class);
        intent.putExtra("container_id", container.id);
        intent.putExtra("exec_path", exe.getPath());
        intent.putExtra("sa_info", info);
        startActivity(intent);
        playButton.setEnabled(true);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        refreshStatus();
    }
}
